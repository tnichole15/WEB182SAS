<?php /*header('Location: https://web182.charliewallin.com/sas/public/'); ?>*/ ?>

<html>
  <head>
    <meta charset="utf-8">
    <title>Project 01</title>"
  </head>

  <body>
    <h1>Project 01 Directory</h1>

    <p>Choose Phase:</p>
    <ul>
      <li><a href="https://www.tnwebworks.website/web182/phase01/public/">Phase 01</a></li>
      <li><a href="https://www.tnwebworks.website/web182/phase02/public/">Phase 02</a></li>
    </ul>
  </body>
</html>