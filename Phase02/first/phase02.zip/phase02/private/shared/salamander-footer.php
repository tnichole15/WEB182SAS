<footer>
  <p>&copy; <?= date('Y'); ?> Southern Appalachian Salamanders</p>
</footer>

</body>
</html>
