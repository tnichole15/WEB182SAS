<?php 

  /*define("DB_SERVER", "localhost");
  define("DB_USER", "sally");
  define("DB_PASS", "somepa55word");
  define("DB_NAME", "salamanders");*/

  // add your credentials for bluehost database

  define("DB_SERVER", "tnwebwor_");
  define("DB_USER", "sally");
  define("DB_PASS", "somepa55word");
  define("DB_NAME", "salamanders");

?>